/* IMS – Internasjonal Matsenter | client app (no build step, no dependencies)
   Data comes from /data/*.json – swap those fetches for a CMS / inventory API later. */

const BASE = document.documentElement.dataset.base || "";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } },
};

/* ------------------------------------------------------------------ state + data */
const S = { lang: store.get("ims-lang", "no"), site: null, products: [], i18n: { no: {}, en: {} }, demo: true, cart: store.get("ims-cart", []), wish: store.get("ims-wish", []) };
const t = (k, vars) => {
  let s = S.i18n[S.lang]?.[k] ?? S.i18n.no?.[k] ?? k;
  if (vars) for (const [a, b] of Object.entries(vars)) s = s.replaceAll(`{${a}}`, b);
  return s;
};
const pname = (p) => (S.lang === "en" ? p.nameEn : p.nameNo) || p.nameNo;
const cats = () => S.site.categories;
const catOf = (slug) => cats().find((c) => c.slug === slug);
const catName = (c) => (S.lang === "en" ? c.en : c.no);
const nok = (n) => n.toLocaleString("nb-NO", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " kr";
const priceNow = (p) => (p.discount ? Math.round(p.price * (1 - p.discount.percent / 100) * 10) / 10 : p.price);
const isVol = (p) => /\b(ml|l)\b/i.test(p.weight);
function unitPrice(p) {
  if (!p.weightG) return null;
  return { v: (priceNow(p) / p.weightG) * 1000, label: t(isVol(p) ? "js.per_l" : "js.per_kg") };
}
const byId = (id) => S.products.find((p) => p.id === id);

async function loadData() {
  const get = (u) => fetch(u).then((r) => { if (!r.ok) throw new Error(u); return r.json(); });
  const [site, prods, i18n] = await Promise.all([get(BASE + "/data/site.json"), get(BASE + "/data/products.json"), get(BASE + "/data/i18n.json")]);
  S.site = site; S.products = prods.products; S.demo = !!prods.demo; S.i18n = i18n;
}

/* ------------------------------------------------------------------ i18n */
function applyI18n(root = document) {
  document.documentElement.lang = S.lang === "en" ? "en" : "nb";
  $$("[data-i18n]", root).forEach((e) => { const v = S.i18n[S.lang]?.[e.dataset.i18n]; if (v != null) e.textContent = v; });
  $$("[data-i18n-placeholder]", root).forEach((e) => { const v = S.i18n[S.lang]?.[e.dataset.i18nPlaceholder]; if (v) e.placeholder = v; });
  $$("[data-i18n-alt]", root).forEach((e) => { const v = S.i18n[S.lang]?.[e.dataset.i18nAlt]; if (v) e.alt = v; });
  $$("[data-valid-to]", root).forEach((e) => {
    const fmt = (d) => new Date(d + "T12:00:00").toLocaleDateString(S.lang === "en" ? "en-GB" : "nb-NO", { day: "numeric", month: "long", year: "numeric" });
    const today = new Date().toISOString().slice(0, 10), from = e.dataset.validFrom, to = e.dataset.validTo;
    const key = today > to ? "js.offer_expired" : today < from ? "js.offer_soon" : "js.offer_active";
    e.textContent = t(key, { d: key === "js.offer_soon" ? fmt(from) : fmt(to) });
    e.style.background = key === "js.offer_active" ? "var(--ok-bg)" : "var(--surface-2)";
  });
  $$("[data-i18n-aria]", root).forEach((e) => { const v = S.i18n[S.lang]?.[e.dataset.i18nAria]; if (v) e.setAttribute("aria-label", v); });
  $$("[data-lang]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.lang === S.lang)));
}
function setLang(l) {
  S.lang = l; store.set("ims-lang", l); applyI18n();
  document.dispatchEvent(new CustomEvent("lang:change"));
}

/* ------------------------------------------------------------------ icons + placeholders */
const ic = (n, c = "") => `<svg class="icon ${c}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;
function media(p, size = "") {
  const c = catOf(p.category);
  if (p.image) return `<img src="${esc(p.image)}" alt="${esc(pname(p))}" loading="lazy" decoding="async" width="400" height="400">`;
  return `<div class="ph" style="--tint:${c?.tint || "#E9EEE7"}" role="img" aria-label="${esc(pname(p))}">${ic(c?.icon || "package")}${size === "lg" ? `<span class="ph__tag">${esc(t("js.demo_img"))}</span>` : ""}</div>`;
}

/* ------------------------------------------------------------------ toast, drawers, modal-ish helpers */
function toast(msg, { error = false, action } = {}) {
  const box = $("[data-toasts]"); if (!box) return;
  const el = document.createElement("div");
  el.className = "toast" + (error ? " toast--error" : "");
  el.innerHTML = `${ic(error ? "alert" : "check")}<span>${esc(msg)}</span>${action ? `<button type="button">${esc(action.label)}</button>` : ""}`;
  if (action) $("button", el).addEventListener("click", () => { action.fn(); el.remove(); });
  box.append(el); setTimeout(() => el.remove(), action ? 6000 : 3200);
}
let openEl = null, lastFocus = null;
function openPanel(el) {
  closePanel();
  lastFocus = document.activeElement; openEl = el;
  el.classList.add("open"); $("[data-backdrop]").classList.add("open"); document.body.classList.add("no-scroll");
  (el.querySelector("[data-close],button,a,input") || el).focus?.();
}
function closePanel() {
  if (!openEl) return;
  openEl.classList.remove("open"); $("[data-backdrop]").classList.remove("open"); document.body.classList.remove("no-scroll");
  openEl = null; lastFocus?.focus?.();
}
function trapFocus(e) {
  if (e.key === "Escape") return closePanel();
  if (e.key !== "Tab" || !openEl) return;
  const f = $$("a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex='-1'])", openEl).filter((x) => x.offsetParent !== null);
  if (!f.length) return;
  const first = f[0], last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}

/* ------------------------------------------------------------------ cart + wishlist */
const saveCart = () => { store.set("ims-cart", S.cart); document.dispatchEvent(new CustomEvent("cart:change")); };
function addToCart(id, qty = 1) {
  const p = byId(id); if (!p || p.availability !== "in_stock") return;
  const row = S.cart.find((r) => r.id === id && !r.saved);
  if (row) row.qty = Math.min(99, row.qty + qty); else S.cart.push({ id, qty, saved: false });
  saveCart();
  toast(t("js.added"), { action: { label: t("js.view_cart"), fn: () => openPanel($("#cart-drawer")) } });
  const c = $("[data-cart-count]"); c?.classList.remove("bump"); void c?.offsetWidth; c?.classList.add("bump");
}
function setQty(id, qty, saved = false) {
  const row = S.cart.find((r) => r.id === id && !!r.saved === saved); if (!row) return;
  row.qty = Math.max(1, Math.min(99, qty)); saveCart();
}
function removeFromCart(id, saved = false) {
  const i = S.cart.findIndex((r) => r.id === id && !!r.saved === saved); if (i < 0) return;
  const [row] = S.cart.splice(i, 1); saveCart();
  toast(t("js.removed"), { action: { label: t("js.undo"), fn: () => { S.cart.push(row); saveCart(); } } });
}
function toggleSaved(id, saved) {
  const row = S.cart.find((r) => r.id === id && !!r.saved === saved); if (!row) return;
  const other = S.cart.find((r) => r.id === id && !!r.saved === !saved);
  if (other) { other.qty += row.qty; S.cart.splice(S.cart.indexOf(row), 1); } else row.saved = !saved;
  saveCart();
}
const active = () => S.cart.filter((r) => !r.saved && byId(r.id));
function totals() {
  let sub = 0, save = 0, n = 0;
  for (const r of active()) { const p = byId(r.id); sub += priceNow(p) * r.qty; save += (p.price - priceNow(p)) * r.qty; n += r.qty; }
  return { sub, save, n, total: sub };
}
function toggleWish(id) {
  const i = S.wish.indexOf(id); i < 0 ? S.wish.push(id) : S.wish.splice(i, 1);
  store.set("ims-wish", S.wish); toast(t(i < 0 ? "js.wish_added" : "js.wish_removed"));
  return i < 0;
}

function qtyControl(id, qty, saved = false) {
  return `<div class="qty qty--sm" role="group" aria-label="${esc(t("js.qty_inc"))}"><button type="button" data-qty="-1" data-id="${id}" data-saved="${saved}" aria-label="${esc(t("js.qty_dec"))}">${ic("minus")}</button><output aria-live="polite">${qty}</output><button type="button" data-qty="1" data-id="${id}" data-saved="${saved}" aria-label="${esc(t("js.qty_inc"))}">${ic("plus")}</button></div>`;
}
function cartLine(r, { compact = false } = {}) {
  const p = byId(r.id);
  return `<div class="cart-item"><a class="cart-item__img" href="${BASE}/product/${p.slug}/" tabindex="-1" aria-hidden="true">${media(p)}</a>
  <div><a class="cart-item__name" href="${BASE}/product/${p.slug}/">${esc(pname(p))}</a><span class="cart-item__meta">${esc(p.weight)} · ${nok(priceNow(p))}</span>
   <div class="cart-item__actions">${qtyControl(p.id, r.qty, !!r.saved)}
    <button class="link-btn" type="button" data-save="${p.id}" data-saved="${!!r.saved}">${esc(t(r.saved ? "js.move_cart" : "js.save_later"))}</button>
    <button class="link-btn" type="button" data-remove="${p.id}" data-saved="${!!r.saved}">${esc(t("js.remove"))}</button></div></div>
  <div class="cart-item__total">${nok(priceNow(p) * r.qty)}</div></div>`;
}
function summaryHtml(withCta) {
  const T = totals();
  return `<h2 style="font-size:var(--fs-lg)">${esc(t("js.cart_title"))} <small style="font-weight:400;color:var(--text-muted)">· ${esc(t("js.items", { n: T.n }))}</small></h2>
  <div class="summary__row"><span>${esc(t("js.subtotal"))}</span><span>${nok(T.sub)}</span></div>
  ${T.save > 0 ? `<div class="summary__row" style="color:var(--success)"><span>${esc(t("js.discounts"))}</span><span>−${nok(T.save)}</span></div>` : ""}
  <div class="summary__row"><span>${esc(t("js.delivery"))}</span><span style="text-align:right">${esc(t("js.delivery_tbd"))}</span></div>
  <div class="summary__row summary__row--total"><span>${esc(t("js.total"))}</span><span>${nok(T.total)}</span></div>
  <p class="field__help">${esc(t("js.vat"))}</p>
  ${withCta ? `<a class="btn btn--primary btn--block ${T.n ? "" : "is-disabled"}" ${T.n ? "" : 'aria-disabled="true" tabindex="-1"'} href="${T.n ? BASE + "/checkout/" : "#"}">${esc(t("js.to_checkout"))}</a>` : ""}`;
}
const emptyCart = () => `<div class="empty">${ic("cart")}<h2>${esc(t("js.cart_empty"))}</h2><p>${esc(t("js.cart_empty_hint"))}</p><a class="btn btn--primary" href="${BASE}/shop/">${esc(t("js.start_shopping"))}</a></div>`;

function renderCart() {
  const T = totals(), cnt = $("[data-cart-count]");
  if (cnt) { cnt.textContent = T.n; cnt.hidden = !T.n; }
  const act = active(), saved = S.cart.filter((r) => r.saved && byId(r.id));
  const dBody = $("[data-cart-drawer-body]"), dFoot = $("[data-cart-drawer-foot]");
  if (dBody) {
    dBody.innerHTML = act.length ? act.map((r) => cartLine(r)).join("") : emptyCart();
    dFoot.innerHTML = act.length ? `<div class="summary__row summary__row--total" style="border:0;margin:0;padding-top:0"><span>${esc(t("js.subtotal"))}</span><span>${nok(T.sub)}</span></div><div style="display:grid;gap:8px;margin-top:8px"><a class="btn btn--primary" href="${BASE}/checkout/">${esc(t("js.to_checkout"))}</a><a class="btn btn--ghost" href="${BASE}/cart/">${esc(t("js.view_cart"))}</a></div>` : "";
  }
  const page = $("[data-cart-page]");
  if (page) {
    page.innerHTML = (act.length ? act.map((r) => cartLine(r)).join("") : emptyCart())
      + (saved.length ? `<h2 style="margin-top:var(--s6);font-size:var(--fs-h3)">${esc(t("js.saved_title"))}</h2>${saved.map((r) => cartLine(r)).join("")}` : "");
  }
  const sum = $("[data-cart-summary]");
  if (sum && document.body.dataset.page === "cart") sum.innerHTML = summaryHtml(true);
  if (sum && document.body.dataset.page === "checkout") sum.innerHTML = summaryHtml(false);
  $$("[data-add]").forEach(() => {});
}

/* ------------------------------------------------------------------ product card */
function priceBlock(p, big = false) {
  const now = priceNow(p), u = unitPrice(p);
  return `<div class="price">${p.discount ? `<span class="price__old"><span class="sr-only">${esc(t("js.was"))} </span>${nok(p.price)}</span>` : ""}<span class="price__now ${p.discount ? "price__now--sale" : ""}">${nok(now)}</span>${u ? `<span class="price__unit">${nok(u.v).replace(" kr", "")} ${esc(u.label)}</span>` : ""}</div>`;
}
function card(p) {
  const out = p.availability !== "in_stock", wished = S.wish.includes(p.id);
  return `<article class="product-card ${out ? "is-out" : ""}" data-reveal>
  <a class="product-card__media" href="${BASE}/product/${p.slug}/" tabindex="-1" aria-hidden="true">${media(p)}</a>
  ${p.discount ? `<span class="badge">${esc(t("js.save_pct", { n: p.discount.percent }))}</span>` : out ? `<span class="badge badge--muted">${esc(t("js.out"))}</span>` : ""}
  <button class="wish" type="button" data-wish="${p.id}" aria-pressed="${wished}" aria-label="${esc(t(wished ? "js.wish_remove" : "js.wish_add"))}">${ic("heart")}</button>
  <div class="product-card__body"><a class="product-card__name" href="${BASE}/product/${p.slug}/">${esc(pname(p))}</a>
   <span class="product-card__meta">${p.brand ? esc(p.brand) + " · " : ""}${esc(p.weight)}</span>
   <div class="product-card__foot">${priceBlock(p)}
    <button class="btn btn--primary add-btn" type="button" data-add="${p.id}" ${out ? "disabled" : ""} aria-label="${esc(t("js.add") + ": " + pname(p))}">${ic("plus")}<span class="label-long">${esc(t("js.add.short"))}</span></button></div></div></article>`;
}
function emptyState(title, hint, clear) {
  return `<div class="empty">${ic("search")}<h3>${esc(title)}</h3><p>${esc(hint)}</p>${clear ? `<button class="btn btn--ghost" type="button" data-clear-filters>${esc(t("js.clear_filters"))}</button>` : ""}</div>`;
}
const errorState = () => `<div class="empty">${ic("alert")}<h3>${esc(t("js.load_error"))}</h3><button class="btn btn--primary" type="button" onclick="location.reload()">${esc(t("js.retry"))}</button></div>`;

/* ------------------------------------------------------------------ search (fuzzy, NO + EN) */
const norm = (s) => String(s || "").toLowerCase().replace(/æ/g, "ae").replace(/ø/g, "o").replace(/å/g, "a").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9 ]/g, " ");
function lev(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 9;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
function tokenScore(q, words) {
  let best = 0;
  for (const w of words) {
    if (w === q) best = Math.max(best, 4);
    else if (w.startsWith(q)) best = Math.max(best, 3);
    else if (q.length > 3 && w.includes(q)) best = Math.max(best, 2);
    else if (q.length >= 4 && lev(q, w.slice(0, q.length + 1)) <= (q.length >= 7 ? 2 : 1) || (q.length >= 4 && lev(q, w) <= (q.length >= 7 ? 2 : 1))) best = Math.max(best, 1);
  }
  return best;
}
let index = null;
function buildIndex() {
  index = S.products.map((p) => {
    const c = catOf(p.category);
    const words = norm([p.nameNo, p.nameEn, p.brand, p.keywords, c.no, c.en].join(" ")).split(/\s+/).filter(Boolean);
    return { p, words, name: norm(p.nameNo + " " + p.nameEn) };
  });
}
function searchProducts(q) {
  const qs = norm(q).split(/\s+/).filter(Boolean); if (!qs.length) return [];
  if (!index) buildIndex();
  const res = [];
  for (const it of index) {
    let total = 0, ok = true;
    for (const w of qs) { const s = tokenScore(w, it.words); if (!s) { ok = false; break; } total += s; }
    if (ok) res.push({ p: it.p, score: total + (it.name.startsWith(qs[0]) ? 2 : 0) });
  }
  return res.sort((a, b) => b.score - a.score).map((r) => r.p);
}
function initSearch() {
  $$("[data-search]").forEach((form) => {
    const input = $("input", form), panel = $(".search-panel", form);
    let items = [], sel = -1, timer;
    const close = () => { panel.hidden = true; input.setAttribute("aria-expanded", "false"); sel = -1; };
    const render = () => {
      const q = input.value.trim(); if (!q) return close();
      const prods = searchProducts(q), top = prods.slice(0, 5);
      const catHits = cats().filter((c) => norm(c.no + " " + c.en).split(" ").some((w) => tokenScore(norm(q).split(" ")[0], [w]) >= 1) || prods.slice(0, 8).some((p) => p.category === c.slug)).slice(0, 3);
      const brands = [...new Set(prods.map((p) => p.brand).filter(Boolean))].slice(0, 3);
      let h = "";
      if (top.length) h += `<div class="search-group" role="group"><h3>${esc(t("js.search_products"))}</h3>${top.map((p) => `<a class="search-item" role="option" href="${BASE}/product/${p.slug}/">${esc(pname(p))}<small>${nok(priceNow(p))}</small></a>`).join("")}</div>`;
      if (catHits.length) h += `<div class="search-group" role="group"><h3>${esc(t("js.search_categories"))}</h3>${catHits.map((c) => `<a class="search-item" role="option" href="${BASE}/shop/${c.slug}/">${esc(catName(c))}</a>`).join("")}</div>`;
      if (brands.length) h += `<div class="search-group" role="group"><h3>${esc(t("js.search_brands"))}</h3>${brands.map((b) => `<a class="search-item" role="option" href="${BASE}/shop/?q=${encodeURIComponent(b)}">${esc(b)}</a>`).join("")}</div>`;
      h += top.length ? `<a class="search-item" role="option" href="${BASE}/shop/?q=${encodeURIComponent(q)}" style="font-weight:600">${esc(t("js.search_all", { q }))}</a>` : `<div class="search-empty">${esc(t("js.search_none", { q }))}</div>`;
      panel.innerHTML = h; panel.hidden = false; input.setAttribute("aria-expanded", "true");
      items = $$("[role=option]", panel); sel = -1;
    };
    input.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(render, 120); });
    input.addEventListener("focus", () => input.value && render());
    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") return close();
      if (!["ArrowDown", "ArrowUp"].includes(e.key) || panel.hidden) return;
      e.preventDefault();
      sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
      items.forEach((x, i) => x.setAttribute("aria-selected", String(i === sel)));
      items[sel]?.scrollIntoView({ block: "nearest" });
    });
    form.addEventListener("submit", (e) => { if (sel >= 0) { e.preventDefault(); items[sel].click(); } });
    document.addEventListener("click", (e) => { if (!form.contains(e.target)) close(); });
  });
}

/* ------------------------------------------------------------------ shop (filters, sort, pagination) */
const PAGE = 12;
function initShop() {
  const grid = $("[data-grid]"); if (!grid) return;
  const fixedCat = document.body.dataset.category || null;
  const params = new URLSearchParams(location.search);
  const f = { q: params.get("q") || "", cats: new Set(fixedCat ? [fixedCat] : params.getAll("cat")), min: params.get("min") || "", max: params.get("max") || "", brands: new Set(params.getAll("brand")), organic: params.get("organic") === "1", stock: params.get("stock") === "1", disc: params.get("disc") === "1", weight: params.get("w") || "any", diet: new Set(params.getAll("diet")), sort: params.get("sort") || "rel", page: +params.get("page") || 1 };
  const panel = $("[data-filters]"), sortEl = $("[data-sort]");
  const brands = [...new Set(S.products.map((p) => p.brand).filter(Boolean))].sort();

  const check = (name, val, label, checked) => `<label class="check"><input type="checkbox" name="${name}" value="${esc(val)}" ${checked ? "checked" : ""}><span>${esc(label)}</span></label>`;
  function buildPanel() {
    panel.innerHTML = `<div class="filters__title"><h2 id="filters-title" style="font-size:var(--fs-lg);margin:0">${esc(t("shop.filters"))}</h2><div><button class="link-btn" type="button" data-clear-filters>${esc(t("js.clear_filters"))}</button><button class="icon-btn filters__close" type="button" data-close-filters aria-label="${esc(t("close"))}">${ic("x")}</button></div></div>
    ${fixedCat ? "" : `<fieldset class="filter-group"><legend>${esc(t("f.cat"))}</legend>${cats().map((c) => check("cat", c.slug, catName(c), f.cats.has(c.slug))).join("")}</fieldset>`}
    <fieldset class="filter-group"><legend>${esc(t("f.price"))}</legend><div class="price-range"><input class="input" type="number" inputmode="numeric" min="0" name="min" placeholder="0" value="${esc(f.min)}" aria-label="${esc(t("f.min"))}"><span>–</span><input class="input" type="number" inputmode="numeric" min="0" name="max" placeholder="500" value="${esc(f.max)}" aria-label="${esc(t("f.max"))}"></div></fieldset>
    ${brands.length ? `<fieldset class="filter-group"><legend>${esc(t("js.brand"))}</legend>${brands.map((b) => check("brand", b, b, f.brands.has(b))).join("")}</fieldset>` : ""}
    <fieldset class="filter-group"><legend>${esc(t("f.more"))}</legend>${check("organic", "1", t("f.organic"), f.organic)}${check("stock", "1", t("f.stock"), f.stock)}${check("disc", "1", t("f.disc"), f.disc)}</fieldset>
    <fieldset class="filter-group"><legend>${esc(t("js.weight"))}</legend>${[["any", "js.w_any"], ["s", "js.w_small"], ["m", "js.w_mid"], ["l", "js.w_big"]].map(([v, k]) => `<label class="radio"><input type="radio" name="w" value="${v}" ${f.weight === v ? "checked" : ""}><span>${esc(t(k))}</span></label>`).join("")}</fieldset>
    <fieldset class="filter-group"><legend>${esc(t("f.diet"))}</legend>${["vegetarian", "vegan", "gluten-free"].map((d) => check("diet", d, t("js.dietary." + d), f.diet.has(d))).join("")}</fieldset>
    <div class="filters__apply"><button class="btn btn--primary btn--block" type="button" data-close-filters><span data-count-btn></span></button></div>`;
    sortEl.innerHTML = [["rel", "js.sort_rel"], ["pa", "js.sort_pa"], ["pd", "js.sort_pd"], ["n", "js.sort_n"], ["d", "js.sort_d"]].map(([v, k]) => `<option value="${v}" ${f.sort === v ? "selected" : ""}>${esc(t(k))}</option>`).join("");
  }
  function readPanel() {
    f.cats = fixedCat ? new Set([fixedCat]) : new Set($$("[name=cat]:checked", panel).map((x) => x.value));
    f.min = $("[name=min]", panel).value; f.max = $("[name=max]", panel).value;
    f.brands = new Set($$("[name=brand]:checked", panel).map((x) => x.value));
    f.organic = $("[name=organic]", panel).checked; f.stock = $("[name=stock]", panel).checked; f.disc = $("[name=disc]", panel).checked;
    f.weight = $("[name=w]:checked", panel)?.value || "any";
    f.diet = new Set($$("[name=diet]:checked", panel).map((x) => x.value));
    f.page = 1;
  }
  const wOk = (p) => f.weight === "any" || (f.weight === "s" ? p.weightG > 0 && p.weightG < 500 : f.weight === "m" ? p.weightG >= 500 && p.weightG <= 1000 : p.weightG > 1000);
  function filtered() {
    let list = f.q ? searchProducts(f.q) : [...S.products];
    list = list.filter((p) => (!f.cats.size || f.cats.has(p.category)) && (!f.min || priceNow(p) >= +f.min) && (!f.max || priceNow(p) <= +f.max)
      && (!f.brands.size || f.brands.has(p.brand)) && (!f.organic || p.organic) && (!f.stock || p.availability === "in_stock") && (!f.disc || p.discount)
      && wOk(p) && [...f.diet].every((d) => p.dietary?.includes(d)));
    const s = { pa: (a, b) => priceNow(a) - priceNow(b), pd: (a, b) => priceNow(b) - priceNow(a), n: (a, b) => pname(a).localeCompare(pname(b), S.lang === "en" ? "en" : "nb"), d: (a, b) => (b.discount?.percent || 0) - (a.discount?.percent || 0) }[f.sort];
    return s ? list.sort(s) : list;
  }
  function syncUrl() {
    const u = new URLSearchParams();
    if (f.q) u.set("q", f.q); if (!fixedCat) f.cats.forEach((c) => u.append("cat", c));
    if (f.min) u.set("min", f.min); if (f.max) u.set("max", f.max); f.brands.forEach((b) => u.append("brand", b));
    if (f.organic) u.set("organic", "1"); if (f.stock) u.set("stock", "1"); if (f.disc) u.set("disc", "1");
    if (f.weight !== "any") u.set("w", f.weight); f.diet.forEach((d) => u.append("diet", d)); if (f.sort !== "rel") u.set("sort", f.sort); if (f.page > 1) u.set("page", f.page);
    history.replaceState(null, "", location.pathname + (u.toString() ? "?" + u : ""));
  }
  function render() {
    const list = filtered(), pages = Math.max(1, Math.ceil(list.length / PAGE)); f.page = Math.min(f.page, pages);
    const slice = list.slice((f.page - 1) * PAGE, f.page * PAGE);
    const countTxt = list.length === 1 ? t("js.product_count1") : t("js.products_count", { n: list.length });
    $("[data-count]").textContent = countTxt; const cb = $("[data-count-btn]"); if (cb) cb.textContent = countTxt;
    grid.innerHTML = slice.length ? slice.map(card).join("") : emptyState(t("js.no_results"), t("js.no_results_hint"), true);
    const pg = $("[data-pagination]");
    pg.innerHTML = pages > 1 ? `<button type="button" data-page="${f.page - 1}" ${f.page === 1 ? "disabled" : ""} aria-label="${esc(t("js.prev"))}">‹</button>${Array.from({ length: pages }, (_, i) => `<button type="button" data-page="${i + 1}" ${i + 1 === f.page ? 'aria-current="page"' : ""} aria-label="${esc(t("js.page", { n: i + 1 }))}">${i + 1}</button>`).join("")}<button type="button" data-page="${f.page + 1}" ${f.page === pages ? "disabled" : ""} aria-label="${esc(t("js.next"))}">›</button>` : "";
    syncUrl(); revealAll();
  }
  buildPanel(); render();
  panel.addEventListener("change", () => { readPanel(); render(); });
  panel.addEventListener("input", (e) => { if (e.target.type === "number") { readPanel(); render(); } });
  sortEl.addEventListener("change", () => { f.sort = sortEl.value; f.page = 1; render(); });
  $("[data-pagination]").addEventListener("click", (e) => { const b = e.target.closest("[data-page]"); if (b && !b.disabled) { f.page = +b.dataset.page; render(); $("[data-grid]").scrollIntoView({ behavior: "smooth", block: "start" }); } });
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-clear-filters]")) { Object.assign(f, { q: "", cats: new Set(fixedCat ? [fixedCat] : []), min: "", max: "", brands: new Set(), organic: false, stock: false, disc: false, weight: "any", diet: new Set(), page: 1 }); buildPanel(); render(); }
    if (e.target.closest("[data-open-filters]")) openPanel(panel);
    if (e.target.closest("[data-close-filters]")) closePanel();
  });
  document.addEventListener("lang:change", () => { buildPanel(); render(); });
  document.addEventListener("cart:change", () => {});
}

/* ------------------------------------------------------------------ product detail */
function initPdp() {
  const root = $("#pdp"); if (!root) return;
  const p = S.products.find((x) => x.slug === root.dataset.slug);
  if (!p) { root.innerHTML = `<div class="empty">${ic("search")}<h2>${esc(t("js.not_found"))}</h2><a class="btn btn--primary" href="${BASE}/shop/">${esc(t("js.start_shopping"))}</a></div>`; return; }
  let qty = 1;
  const c = catOf(p.category);
  const info = (v) => (v ? `<p>${esc(v)}</p>` : `<p style="color:var(--text-muted)">${esc(t("js.not_provided"))}</p>`);
  function render() {
    const out = p.availability !== "in_stock", wished = S.wish.includes(p.id), u = unitPrice(p);
    const tabs = [["desc", "js.tab_desc", S.lang === "en" ? p.descriptionEn : p.descriptionNo], ["ing", "js.tab_ing", p.ingredients], ["all", "js.tab_all", p.allergens], ["nut", "js.tab_nut", p.nutrition], ["sto", "js.tab_sto", p.storage]];
    document.title = `${pname(p)} | IMS`;
    $("h1", root)?.remove();
    root.innerHTML = `<div class="pdp__gallery"><div class="media" style="position:relative">${p.discount ? `<span class="badge">${esc(t("js.save_pct", { n: p.discount.percent }))}</span>` : ""}${media(p, "lg")}</div></div>
    <div><p class="eyebrow"><a href="${BASE}/shop/${c.slug}/" style="color:inherit;text-decoration:none">${esc(catName(c))}</a></p><h1 style="font-size:var(--fs-h2)">${esc(pname(p))}</h1>
     <p class="product-card__meta" style="font-size:var(--fs-sm)">${p.brand ? esc(t("js.brand")) + ": " + esc(p.brand) + " · " : ""}${esc(t("js.weight"))}: ${esc(p.weight)}</p>
     <div class="pdp__price" style="margin-block:var(--s4)">${priceBlock(p, true)}</div>
     <p><span class="availability ${out ? "availability--out" : "availability--in"}">${ic(out ? "x" : "check")}${esc(t(out ? "js.out" : "js.in"))}</span></p>
     <div class="pdp__buy">${out ? "" : `<div class="qty" role="group"><button type="button" data-pq="-1" aria-label="${esc(t("js.qty_dec"))}">${ic("minus")}</button><output aria-live="polite">${qty}</output><button type="button" data-pq="1" aria-label="${esc(t("js.qty_inc"))}">${ic("plus")}</button></div>`}
      <button class="btn btn--primary" type="button" data-pdp-add ${out ? "disabled" : ""}>${ic("cart")}<span>${esc(out ? t("js.out") : t("js.add"))}</span></button>
      <button class="btn btn--ghost" type="button" data-wish="${p.id}" aria-pressed="${wished}" aria-label="${esc(t(wished ? "js.wish_remove" : "js.wish_add"))}" style="width:48px;padding:0">${ic("heart")}</button></div>
     <div class="tabs" data-tabs><div role="tablist">${tabs.map(([id, k], i) => `<button role="tab" id="tab-${id}" aria-controls="pn-${id}" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}">${esc(t(k))}</button>`).join("")}</div>
      ${tabs.map(([id, k, v], i) => `<div role="tabpanel" id="pn-${id}" aria-labelledby="tab-${id}" ${i ? "hidden" : ""}>${info(v)}</div>`).join("")}</div>
     ${S.demo ? `<p class="note" style="margin-top:var(--s4)">${ic("alert")}<span>${esc(t("home.off.demo"))}</span></p>` : ""}
    </div>`;
    const rel = S.products.filter((x) => x.category === p.category && x.id !== p.id).slice(0, 4);
    $("#pdp-related")?.remove();
    if (rel.length) root.parentElement.insertAdjacentHTML("beforeend", `<section id="pdp-related" class="section" style="padding-top:0"><h2>${esc(t("js.related"))}</h2><div class="product-grid product-grid--4">${rel.map(card).join("")}</div></section>`);
    const sb = $("[data-sticky-buy]");
    if (sb) { sb.hidden = out; sb.innerHTML = `<div class="price" style="min-width:90px"><span class="price__now">${nok(priceNow(p))}</span></div><button class="btn btn--primary" type="button" data-sticky-add>${ic("cart")}<span>${esc(t("js.add"))}</span></button>`; }
    const main = $("[data-pdp-add]");
    if (main && sb && "IntersectionObserver" in window) { new IntersectionObserver(([e]) => sb.classList.toggle("show", !e.isIntersecting && e.boundingClientRect.top < 0)).observe(main); }
    revealAll();
  }
  render();
  root.addEventListener("click", (e) => {
    const pq = e.target.closest("[data-pq]");
    if (pq) { qty = Math.max(1, Math.min(99, qty + +pq.dataset.pq)); $(".qty output", root).textContent = qty; }
    if (e.target.closest("[data-pdp-add]")) { const b = e.target.closest("button"); b.classList.add("is-loading"); setTimeout(() => { b.classList.remove("is-loading"); addToCart(p.id, qty); }, 250); }
    const tab = e.target.closest("[role=tab]");
    if (tab) selectTab(tab);
  });
  root.addEventListener("keydown", (e) => {
    const tab = e.target.closest("[role=tab]"); if (!tab || !["ArrowRight", "ArrowLeft"].includes(e.key)) return;
    const all = $$("[role=tab]", root), i = all.indexOf(tab), n = all[(i + (e.key === "ArrowRight" ? 1 : -1) + all.length) % all.length]; n.focus(); selectTab(n);
  });
  function selectTab(tab) { $$("[role=tab]", root).forEach((x) => { const on = x === tab; x.setAttribute("aria-selected", on); x.tabIndex = on ? 0 : -1; $("#" + x.getAttribute("aria-controls")).hidden = !on; }); }
  $("[data-sticky-buy]")?.addEventListener("click", (e) => { if (e.target.closest("[data-sticky-add]")) addToCart(p.id, qty); });
  document.addEventListener("lang:change", render);
}

/* ------------------------------------------------------------------ home / offers lists */
function offersHtml(limit) {
  const list = S.products.filter((p) => p.discount && p.availability === "in_stock").slice(0, limit || 99);
  return list.map((p) => {
    const v = p.discount.validTo ? t("js.valid_to", { d: new Date(p.discount.validTo).toLocaleDateString("nb-NO") }) : t("js.valid_demo");
    return card(p).replace('<div class="product-card__foot">', `<span class="product-card__meta" style="color:var(--error);font-weight:600">${esc(v)}</span><div class="product-card__foot">`);
  }).join("") || emptyState(t("js.no_results"), "", false);
}
function initLists() {
  const render = () => {
    const f = $("[data-featured]"); if (f) f.innerHTML = S.products.filter((p) => p.availability === "in_stock").slice(0, 8).map(card).join("");
    $$("[data-offers]").forEach((o) => { o.innerHTML = offersHtml(+o.dataset.limit || 0); });
    revealAll();
  };
  render(); document.addEventListener("lang:change", render);
}

/* ------------------------------------------------------------------ forms */
function fieldErr(field, msg) {
  field.classList.toggle("has-error", !!msg);
  const e = $(".field__error", field); if (e) e.textContent = msg || "";
  const i = $("input,select,textarea", field); if (i) i.setAttribute("aria-invalid", msg ? "true" : "false");
}
const validators = {
  required: (v) => (v.trim() ? "" : t("js.err_required")),
  email: (v) => (!v.trim() ? t("js.err_required") : /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "" : t("js.err_email")),
  phone: (v) => (!v.trim() ? t("js.err_required") : /^[+\d][\d\s-]{6,}$/.test(v.trim()) ? "" : t("js.err_phone")),
  postal: (v) => (/^\d{4}$/.test(v.trim()) ? "" : t("js.err_postal")),
};
function validateField(input) {
  const id = input.id, f = input.closest("[data-field]"); if (!f) return true;
  let msg = "";
  const val = input.value;
  if (!input.required && !val.trim()) msg = "";
  else if (input.type === "email") msg = validators.email(val);
  else if (input.type === "tel") msg = validators.phone(val);
  else if (id === "d-postal") msg = validators.postal(val);
  else if (input.required) msg = validators.required(val);
  fieldErr(f, msg); return !msg;
}
function validateAll(scope, form) {
  let ok = true, firstBad = null;
  $$("input:not([type=radio]):not([type=checkbox]),textarea,select", scope).forEach((i) => { if (i.closest("[hidden]")) return; if (!validateField(i)) { ok = false; firstBad ??= i; } });
  const sum = $("[data-form-summary]", form);
  if (sum) { sum.hidden = ok; if (!ok) { sum.textContent = t("js.err_summary"); firstBad.focus(); } }
  return ok;
}
function initContact() {
  const form = $("[data-contact-form]"); if (!form) return;
  form.addEventListener("focusout", (e) => { if (e.target.matches("input,textarea")) validateField(e.target); });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validateAll(form, form)) return;
    const b = $("button[type=submit]", form); b.classList.add("is-loading");
    setTimeout(() => {
      b.classList.remove("is-loading");
      const body = `${$("#c-msg").value}\n\n${$("#c-name").value}${$("#c-phone").value ? " / " + $("#c-phone").value : ""}`;
      const mail = `mailto:${S.site.business.email}?subject=${encodeURIComponent($("#c-subject").value)}&body=${encodeURIComponent(body)}`;
      $("[data-form-result]", form).innerHTML = `<div class="alert alert--warn" role="status">${esc(t("js.contact_demo"))} <a href="${mail}">${esc(t("js.contact_mailto"))}</a></div>`;
    }, 500);
  });
}

/* ------------------------------------------------------------------ checkout (DEMO) */
function initCheckout() {
  const form = $("[data-checkout]"); if (!form) return;
  let step = 1;
  const secs = $$("[data-step]", form), prev = $("[data-prev]", form), next = $("[data-next]", form);
  const map = { 1: "delivery", 2: "delivery", 3: "payment", 4: "payment" };
  const labels = () => (step === 4 ? t("js.place_order") : t("js.continue"));
  function show() {
    secs.forEach((s) => (s.hidden = +s.dataset.step !== step));
    prev.hidden = step === 1; next.textContent = labels();
    $$("[data-step-ind]").forEach((li) => { li.toggleAttribute("aria-current", false); li.classList.remove("done"); });
    const order = ["cart", "delivery", "payment", "confirm"], cur = step < 3 ? "delivery" : "payment";
    $$("[data-step-ind]").forEach((li) => { const k = li.dataset.stepInd; if (k === cur) li.setAttribute("aria-current", "step"); else if (order.indexOf(k) < order.indexOf(cur)) li.classList.add("done"); });
    if (step === 4) review();
    $(`[data-step="${step}"] h2`, form)?.focus?.();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  const val = (id) => $("#" + id)?.value.trim() || "";
  function review() {
    const m = $("[name=delivery]:checked", form)?.value, pay = $("[name=payment]:checked", form)?.value;
    const store = S.site.stores.find((s) => s.slug === $("#d-store").value);
    $("[data-review]", form).innerHTML = `<div class="summary" style="margin-bottom:var(--s4)"><dl class="dl"><dt>${esc(t("f.name"))}</dt><dd>${esc(val("d-name"))}</dd><dt>${esc(t("f.phone2"))}</dt><dd>${esc(val("d-phone"))}</dd><dt>${esc(t("js.ship_to"))}</dt><dd>${esc(val("d-address"))}${val("d-apt") ? ", " + esc(val("d-apt")) : ""}, ${esc(val("d-postal"))} ${esc(val("d-city"))}</dd><dt>${esc(t("co.s2").replace(/^\d\.\s*/, ""))}</dt><dd>${esc(t(m === "pickup" ? "js.method_pickup" : "js.method_delivery"))}${m === "pickup" && store ? " – " + esc(store.name) : ""}</dd><dt>${esc(t("co.s3").replace(/^\d\.\s*/, ""))}</dt><dd>${esc(t("js.method_" + pay))}</dd></dl></div>${active().map((r) => { const p = byId(r.id); return `<div class="summary__row"><span>${r.qty} × ${esc(pname(p))}</span><span>${nok(priceNow(p) * r.qty)}</span></div>`; }).join("")}`;
  }
  function stepOk() {
    const sec = $(`[data-step="${step}"]`, form);
    if (step === 1) return validateAll(sec, form);
    const f = (name, msgKey) => { const wrap = $(`[name=${name}]`, sec)?.closest("[data-field]"); const ok = !!$(`[name=${name}]:checked`, form); fieldErr(wrap, ok ? "" : t(msgKey)); return ok; };
    if (step === 2) return f("delivery", "js.err_delivery");
    if (step === 3) return f("payment", "js.err_payment");
    const wrap = $("#d-terms").closest("[data-field]"), ok = $("#d-terms").checked; fieldErr(wrap, ok ? "" : t("js.err_consent")); return ok;
  }
  form.addEventListener("focusout", (e) => { if (e.target.matches("input:not([type=radio]):not([type=checkbox])")) validateField(e.target); });
  form.addEventListener("change", (e) => { if (e.target.name === "delivery") $("[data-pickup-store]").hidden = e.target.value !== "pickup"; });
  prev.addEventListener("click", () => { step--; show(); });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!active().length) { $("[data-form-summary]", form).hidden = false; $("[data-form-summary]", form).textContent = t("js.cart_empty"); return; }
    if (!stepOk()) return;
    if (step < 4) { step++; show(); return; }
    next.classList.add("is-loading"); next.textContent = t("js.processing");
    setTimeout(() => {
      const T = totals(), order = "DEMO-" + Math.random().toString(36).slice(2, 8).toUpperCase();
      const lines = active().map((r) => { const p = byId(r.id); return `<div class="summary__row"><span>${r.qty} × ${esc(pname(p))}</span><span>${nok(priceNow(p) * r.qty)}</span></div>`; }).join("");
      const conf = $("[data-confirmation]");
      form.hidden = true; $("[data-stepper]").hidden = true; conf.hidden = false;
      $$("[data-cart-summary]").forEach((x) => (x.hidden = true));
      conf.innerHTML = `<div class="confirm"><div class="confirm__check"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg></div><h2 tabindex="-1" id="confirm-h">${esc(t("co.done"))}</h2>
        <p class="alert alert--warn" style="text-align:left">${esc(t("js.order_demo"))}</p>
        <div class="summary" style="text-align:left;margin-block:var(--s5)"><div class="summary__row"><strong>${esc(t("co.order_no"))}</strong><span>${order}</span></div><div class="summary__row"><span>${esc(t("js.ship_to"))}</span><span style="text-align:right">${esc(val("d-address"))}, ${esc(val("d-postal"))} ${esc(val("d-city"))}</span></div>${lines}<div class="summary__row summary__row--total"><span>${esc(t("js.total"))}</span><span>${nok(T.total)}</span></div></div>
        <a class="btn btn--primary" href="${BASE}/shop/">${esc(t("co.continue"))}</a></div>`;
      S.cart = S.cart.filter((r) => r.saved); saveCart(); $("#confirm-h").focus(); window.scrollTo({ top: 0 });
    }, 900);
  });
  show();
  document.addEventListener("lang:change", () => { next.textContent = labels(); });
}

/* ------------------------------------------------------------------ stores: hours highlight + consent map */
function initStores() {
  const days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"], today = days[new Date().getDay()];
  $$("[data-hours] tr").forEach((tr) => tr.classList.toggle("today", tr.dataset.day === today));
  $$("[data-map]").forEach((m) => m.addEventListener("click", (e) => {
    if (!e.target.closest("[data-map-load]")) return;
    m.innerHTML = `<iframe src="${esc(m.dataset.map)}" title="${esc(t("js.map_show"))}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`;
  }));
}

/* ------------------------------------------------------------------ shared UI wiring */
function revealAll() {
  const els = $$("[data-reveal]:not(.in)");
  if (!("IntersectionObserver" in window) || matchMedia("(prefers-reduced-motion: reduce)").matches) return els.forEach((e) => e.classList.add("in"));
  const io = new IntersectionObserver((en) => en.forEach((x) => { if (x.isIntersecting) { x.target.classList.add("in"); io.unobserve(x.target); } }), { rootMargin: "0px 0px -5% 0px" });
  els.forEach((e) => io.observe(e));
}
function wireGlobal() {
  document.addEventListener("keydown", trapFocus);
  document.addEventListener("click", (e) => {
    const a = e.target.closest.bind(e.target);
    if (a("[data-open-menu]")) openPanel($("#menu-drawer"));
    if (a("[data-open-cart]")) openPanel($("#cart-drawer"));
    if (a("[data-close]") || a("[data-backdrop]")) closePanel();
    if (a("#menu-drawer a")) closePanel();
    const lang = a("[data-lang]"); if (lang) setLang(lang.dataset.lang);
    const add = a("[data-add]"); if (add && !add.disabled) { add.classList.add("is-loading"); setTimeout(() => { add.classList.remove("is-loading"); addToCart(add.dataset.add); }, 220); }
    const w = a("[data-wish]"); if (w) { const on = toggleWish(w.dataset.wish); $$(`[data-wish="${w.dataset.wish}"]`).forEach((b) => { b.setAttribute("aria-pressed", String(on)); b.setAttribute("aria-label", t(on ? "js.wish_remove" : "js.wish_add")); }); }
    const q = a("[data-qty]"); if (q) { const row = S.cart.find((r) => r.id === q.dataset.id && String(!!r.saved) === q.dataset.saved); if (row) setQty(row.id, row.qty + +q.dataset.qty, !!row.saved); }
    const rm = a("[data-remove]"); if (rm) removeFromCart(rm.dataset.remove, rm.dataset.saved === "true");
    const sv = a("[data-save]"); if (sv) toggleSaved(sv.dataset.save, sv.dataset.saved === "true");
  });
  document.addEventListener("cart:change", renderCart);
  document.addEventListener("lang:change", renderCart);
  const ck = $("[data-cookie]");
  if (ck && !store.get("ims-cookie-ok", false)) { ck.hidden = false; $("[data-cookie-ok]").addEventListener("click", () => { store.set("ims-cookie-ok", true); ck.hidden = true; }); }
}

/* ------------------------------------------------------------------ boot */
(async function boot() {
  wireGlobal();
  try { await loadData(); }
  catch (err) {
    console.error(err);
    ["[data-grid]", "[data-featured]", "[data-offers]", "#pdp"].forEach((s) => $$(s).forEach((el) => (el.innerHTML = errorState())));
    return;
  }
  applyI18n(); renderCart(); initSearch(); initShop(); initPdp(); initLists(); initContact(); initCheckout(); initStores(); revealAll();
})();
